**特别声明：本项目中的展示图片归奈雪の茶所有。**

### 源码地址

github地址: [https://github.com/tinypuppet/nxdc-milktea](https://github.com/tinypuppet/nxdc-milktea)

gitee地址：[https://gitee.com/tinypuppet/nxdc-milktea](https://gitee.com/tinypuppet/nxdc-milktea)

uni-app插件市场地址:[https://ext.dcloud.net.cn/plugin?id=1807](https://ext.dcloud.net.cn/plugin?id=1807)

### 简介

一套仿奈雪の茶小程序的项目模板。

如果你喜欢这套模板，请给个star呗~

### 个人说明

如有问题，请联系QQ或微信``327722714``。

### 说明

1. 本项目包含：

	- 首页
	- 点餐（自取和外卖两种方式，有基本的点餐逻辑处理）
	- 取餐
	- 我的
	- 积分商城
	- 积分商城详情页
	- 积分签到
	- 会员码
	- 我的卡券
	- 收货地址
	- 我的资料
	- 我的订单
	- 订单详情
	- 余额
	- 会员卷包
	- 卷包详情
	- 订单评价
	- 买茶送包
	- 更多服务
	- 开发票
	- 礼品卡

2. 所有数据都是静态的，保存在api文件夹下。

### 展示效果

|首页|点餐|饮品详情|我的|取餐|
|---|---|---|---|---|
|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/fafaa180-94f3-11ea-9423-8760f636375f_0.jpg?v=1590130842)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/fafaa180-94f3-11ea-9423-8760f636375f_1.jpg?v=1590130842)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/fafaa180-94f3-11ea-9423-8760f636375f_2.jpg?v=1590130842)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/fafaa180-94f3-11ea-9423-8760f636375f_3.jpg?v=1590130842)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/fafaa180-94f3-11ea-9423-8760f636375f_4.jpg?v=1590130842)|
