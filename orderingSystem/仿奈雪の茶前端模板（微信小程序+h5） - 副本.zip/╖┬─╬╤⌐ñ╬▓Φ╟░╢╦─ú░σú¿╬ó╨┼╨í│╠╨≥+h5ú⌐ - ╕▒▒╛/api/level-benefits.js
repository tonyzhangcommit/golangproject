export default [{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/f6bdc61b9356e87d03.jpg",
		"cardName": "V1",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 2
				}],
				"benefitsName": "开卡特权",
				"benefitsType": 0
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "会员日特权",
				"benefitsType": 4
			}
		],
		"level": 1
	},
	{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/fd13fff0e873b8c06d.jpg",
		"cardName": "V2",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 2
				}],
				"benefitsName": "升级特权",
				"benefitsType": 1
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "生日特权",
				"benefitsType": 3
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "会员日特权",
				"benefitsType": 4
			}
		],
		"level": 2
	},
	{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/a292980f9803aa4504.jpg",
		"cardName": "V3",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 3
				}],
				"benefitsName": "升级特权",
				"benefitsType": 1
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "生日特权",
				"benefitsType": 3
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "会员日特权",
				"benefitsType": 4
			}
		],
		"level": 3
	},
	{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/6fc9b939b9912c4387.jpg",
		"cardName": "V4",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 3
				}],
				"benefitsName": "升级特权",
				"benefitsType": 1
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "生日特权",
				"benefitsType": 3
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "会员日特权",
				"benefitsType": 4
			}
		],
		"level": 4
	},
	{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/460bdca3e1e7f87def.jpg",
		"cardName": "V5",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 6
				}],
				"benefitsName": "升级特权",
				"benefitsType": 1
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "生日特权",
				"benefitsType": 3
			}
		],
		"level": 5
	},
	{
		"picture": "https://images.qmai.cn/s33123/2020/01/20/508ea53092bcf504f3.jpg",
		"cardName": "V6",
		"benefitsSummaries": [{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 6
				}],
				"benefitsName": "升级特权",
				"benefitsType": 1
			},
			{
				"benefitsItemSummaries": [{
					"unitType": 0,
					"benefitsType": 0,
					"num": 1
				}],
				"benefitsName": "生日特权",
				"benefitsType": 3
			}
		],
		"level": 6
	}
]
