export default {
	"is_attendance": 2,
	"total_points": 0,
	"attendance_points": 1,
	"attendance_category": 1,
	"attendance_continuity_day": 1,
	"list": [{
		"points": 1,
		"updated_at": "2020-01-15 05:29:25",
		"attendances_id": 312,
		"id": 770,
		"status": 0,
		"receive_type": 0,
		"created_at": "2019-10-23 19:17:21",
		"coupon_name": "",
		"attendance_category": 1,
		"coupon_id": "0",
		"attendance_day": 1,
		"coupon_num": 0,
		"deleted_at": null
	}]
}
