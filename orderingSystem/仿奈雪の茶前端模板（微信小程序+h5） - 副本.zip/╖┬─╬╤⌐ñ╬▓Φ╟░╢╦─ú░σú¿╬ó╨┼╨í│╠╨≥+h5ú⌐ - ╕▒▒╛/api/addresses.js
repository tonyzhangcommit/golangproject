export default [{
	"id": 1,
	"accept_name": "隔壁老王",
	"mobile": "18666600000",
	"province_name": "广东省",
	"area": 440306,
	"city": 440300,
	"sex": 0,
	"district": {
		"districts": "广东省深圳市南山区",
		"area": "宝安区",
		"city": "深圳市",
		"province": "广东省"
	},
	"street": "有一间公寓八栋",
	"inner": false,
	"lat": "",
	"door_number": "AB1234",
	"is_default": 0,
	"province": 440000,
	"area_name": "南山区",
	"city_name": "深圳市",
	"poiname": ""
}, {
	"id": 2,
	"accept_name": "黄女士",
	"mobile": "18666610000",
	"province_name": "广东省",
	"area": 440306,
	"city": 440300,
	"sex": 1,
	"district": {
		"districts": "广东省深圳市南山区",
		"area": "宝安区",
		"city": "深圳市",
		"province": "广东省"
	},
	"street": "有两间公寓二栋",
	"inner": false,
	"lat": "",
	"door_number": "AB5210",
	"is_default": 0,
	"province": 440000,
	"area_name": "南山区",
	"city_name": "深圳市",
	"poiname": ""
}]
