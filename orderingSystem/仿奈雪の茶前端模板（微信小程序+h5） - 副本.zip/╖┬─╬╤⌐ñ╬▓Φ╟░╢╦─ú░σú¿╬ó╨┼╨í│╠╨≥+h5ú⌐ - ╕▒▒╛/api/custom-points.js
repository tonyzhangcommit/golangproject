export default {
	"soonExpiredPoints": 0,
	"totalPoints": 487,
	"expiredTime": null,
	"foreverPoints": 0
}
